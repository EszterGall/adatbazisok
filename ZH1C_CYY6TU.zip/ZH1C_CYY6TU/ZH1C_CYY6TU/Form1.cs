using System.Windows.Forms;

namespace ZH1C_CYY6TU
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Fibonacci(int n)
        {
            int eredmeny = 0;
            for (int i = 0; i <= n; i++)
            {
                eredmeny += i;
            }
            return eredmeny;
        }
        class TorpedoButton : Button
        {
            string betu;
            public TorpedoButton()
            {
                Height = 40;
                Width = 40;
                BackColor = Color.Gray;
                Text = "";
                betu = Text;
                MouseClick += TorpedoButton_MouseClick;

            }

            private void TorpedoButton_MouseClick(object? sender, MouseEventArgs e)
            {
                if (betu == "")
                {
                    this.BackColor = Color.Red;
                    this.Text = "X";
                    betu = "X";
                    return;

                }
                    
                    if (betu == "X")
                    {
                        this.BackColor = Color.Green;
                        Text = "O";
                        betu = "O";
                        return;
                    }
                    if (betu == "O")
                    {
                        this.BackColor = Color.Gray;
                        Text = "";
                        betu = "";
                        return;
                    }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            List<Sor> lista = new List<Sor>();
            for (int i = 1; i < 15; i++)
            {
                Sor ujSor = new Sor();
                ujSor.Sorszam = i;
                ujSor.Fibonacci = Fibonacci(i);
                lista.Add(ujSor);

            }
            dataGridView1.DataSource = lista;


        }

        private void button1_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    TorpedoButton gomb = new TorpedoButton();
                    gomb.Left = gomb.Width * i;
                    gomb.Top = gomb.Height * j;
                    Controls.Add(gomb);
                }
            }
            
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < int.Parse(textBox1.Text); i++)
            {
                for (int j = 0; j < int.Parse(textBox1.Text); j++)
                {
                    TorpedoButton gomb = new TorpedoButton();
                    Controls.Add(gomb);
                }
            }
        }


    }
}