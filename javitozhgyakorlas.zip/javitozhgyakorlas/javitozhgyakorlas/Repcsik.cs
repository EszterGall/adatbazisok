﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace javitozhgyakorlas
{
    public class Repcsik
    {
        //JaratID,Legitarsasag,IndulasiHely,CelHely,UtasokSzama,IdotartamOra
        public int JaratID { get; set; }
        public string Legitarsasag { get; set; }
        public string IndulasiHely {  get; set; }
        public string CelHely { get; set; }
        public int UtasokSzama { get; set; }
        public int IdotartamOra { get; set; }


    }
}
